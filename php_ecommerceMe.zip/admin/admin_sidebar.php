<div class="col-md-3">
	<p class="lead">Admin Options</p>
	<div class="list-group">
	    <a href="password.php" class="list-group-item">Reset Password</a>
	    <a href="dashboard.php" class="list-group-item">Dashboard</a>
	    <a href="logout.php" class="list-group-item">Logout</a>
	</div>
</div>